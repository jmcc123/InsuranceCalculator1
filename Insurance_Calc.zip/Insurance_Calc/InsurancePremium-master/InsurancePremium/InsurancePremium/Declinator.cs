﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;

namespace InsurancePremium
{
    class Declinator : IDeclinator
    {
        // Backing Fields
        private readonly IReadOnlyList<IDeclinatorRule> rules;

        // Properties
        public IReadOnlyList<IDeclinatorRule> Rules { get { return rules; } }

        /// <summary>
        /// Applies rules to a policy to determin if the policy is declined or not.
        /// </summary>
        /// <param name="rules">The set of rules to apply to a given policy.</param>
        public Declinator(IReadOnlyList<IDeclinatorRule> rules)
        {
            this.rules = rules;
        }

        /// <summary>
        /// Applies the rules in the declinator to a policy.
        /// </summary>
        /// <param name="policy">The poloicy to apply the rules to.</param>
        /// <param name="reason">The reason for declining the policy if applicable.</param>
        /// <returns></returns>
        public bool CalculateIsDeclined(Policy policy, ref string reason)
        {

            foreach (var rule in Rules)
                if (rule.Apply(policy, ref reason))
                    return true;

            return false;
        }
    }
}
