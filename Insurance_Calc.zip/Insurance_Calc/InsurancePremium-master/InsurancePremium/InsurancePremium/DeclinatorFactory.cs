﻿using InsurancePremium.Interfaces;
using InsurancePremium.Rules.Declination;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium
{
    class DeclinatorFactory : IDeclinatorFactory
    {
        public IDeclinator Create()
        {
            List<IDeclinatorRule> rules = new List<IDeclinatorRule>()
            {
                new PolicyStartDateRule(),
                new MinimumDriverAgeRule(),
                new MaximumDriverAgeRule(),
                new MaxDriverClaimsRule(),
                new MaxPolicyClaimsRule()
            };

            return new Declinator(rules);
        }
    }
}
