﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium
{
    public static class Helpers
    {
        public static double TotalYears(this TimeSpan timeSpan)
        {
            return timeSpan.TotalDays / 365.2425;
        }
    }
}
