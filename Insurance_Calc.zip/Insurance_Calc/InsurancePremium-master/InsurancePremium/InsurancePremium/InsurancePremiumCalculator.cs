﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;
using InsurancePremium.Interfaces;

namespace InsurancePremium
{
    public class InsurancePremiumCalculator : IInsurancePremiumCalculator
    {
        // Backing Fields
        private readonly decimal startingPremium;
        private readonly IReadOnlyList<IInsurancePremiumCalculationRule> rules;

        // Properties
        public decimal StartingPremium { get { return startingPremium; } }
        public IReadOnlyList<IInsurancePremiumCalculationRule> Rules { get { return rules; } }

        /// <summary>
        /// Calculates the insurance premium of a policy.
        /// Uses the Command pattern for the implementation of rules.
        /// </summary>
        /// <param name="startingPremium">The base premium before rules are applied.</param>
        /// <param name="rules">A list of if-then rules which increase / decrease the premium.</param>
        public InsurancePremiumCalculator(decimal startingPremium, IReadOnlyList<IInsurancePremiumCalculationRule> rules)
        {
            this.startingPremium = startingPremium;
            this.rules = rules;
        }

        /// <summary>
        /// Calulates the insurance premium for a given policy.
        /// </summary>
        /// <param name="policy">The policy for which the premium is calculated.</param>
        /// <returns>The premium of the policy.</returns>
        public decimal CalculatePremium(Policy policy)
        {
            decimal premium = StartingPremium;

            foreach (var rule in Rules)
                premium = rule.Apply(premium, policy);

            return premium;
        }
    }
}
