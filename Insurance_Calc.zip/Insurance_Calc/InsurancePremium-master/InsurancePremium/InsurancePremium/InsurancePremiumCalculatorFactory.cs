﻿using InsurancePremium.Interfaces;
using InsurancePremium.Rules.PremiumCalculation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium
{
    class InsurancePremiumCalculatorFactory : IInsurancePremiumCalculatorFactory
    {
        private const int CHAUFFEUR_OCCUPATION_ID = 1;
        private const int ACCOUNTANT_OCCUPATION_ID = 2;

        public InsurancePremiumCalculatorFactory()
        {
        }

        public IInsurancePremiumCalculator Create()
        {
            decimal startingPremium = 500m;
            List<IInsurancePremiumCalculationRule> rules = new List<IInsurancePremiumCalculationRule>()
            {
                new DriverOccupationRule(CHAUFFEUR_OCCUPATION_ID, ACCOUNTANT_OCCUPATION_ID),
                new DriverAgeRule(),
                new DriverClaimsRule()
            };

            return new InsurancePremiumCalculator(startingPremium, rules);
        }
    }
}
