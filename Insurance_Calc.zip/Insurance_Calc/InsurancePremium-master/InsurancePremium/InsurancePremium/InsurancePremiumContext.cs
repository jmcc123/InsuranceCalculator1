﻿using InsurancePremium.Models;
using System.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace InsurancePremium
{
    public class InsurancePremiumContext : InsurancePremiumContextAbstract
    {
        public InsurancePremiumContext(InsurancePremiumDBInitialiser initialiser) :
            base("name=InsurancePremiumDB")
        {
            Database.SetInitializer(initialiser);
        }
    }
}
