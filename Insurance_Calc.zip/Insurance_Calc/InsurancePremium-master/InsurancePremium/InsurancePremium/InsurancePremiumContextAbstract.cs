﻿using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium
{
    public abstract class InsurancePremiumContextAbstract : DbContext
    {
        public DbSet<Claim> Claims { get; set; }
        public DbSet<Occupation> Occupations { get; set; }
        public DbSet<Driver> Drivers { get; set; }
        public DbSet<Policy> Policies { get; set; }

        public InsurancePremiumContextAbstract(string dbName) :
            base(dbName)
        {
        }
    }
}
