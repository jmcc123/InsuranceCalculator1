﻿using InsurancePremium.Interfaces;
using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium
{
    public class InsurancePremiumDBInitialiser : DropCreateDatabaseAlways<InsurancePremiumContext>
    {
        private const int CHAUFFEUR_OCCUPATION_ID = 1;
        private const int ACCOUNTANT_OCCUPATION_ID = 2;

        private readonly IInsurancePremiumCalculator premiumCalculator;

        public InsurancePremiumDBInitialiser(IInsurancePremiumCalculator premiumCalculator)
        {
            this.premiumCalculator = premiumCalculator;
        }

        protected override void Seed(InsurancePremiumContext context)
        {
            // Seed the occupations.
            IList<Occupation> defaultOccupations = new List<Occupation>()
            {
                new Occupation { OccupationId = CHAUFFEUR_OCCUPATION_ID, Name = "Chauffeur" },
                new Occupation { OccupationId = ACCOUNTANT_OCCUPATION_ID, Name = "Accountant" }
            };
            context.Occupations.AddRange(defaultOccupations);
            context.SaveChanges();


            // Seed the drivers and claims.
            IList<Driver> defaultDrivers = new List<Driver>()
            {
                new Driver
                {
                    Name = "Glen Brown",
                    DateOfBirth = DateTime.Parse("1992-12-27"),
                    Occupation = context.Occupations.ToList()[0],
                    Claims = new List<Claim>()
                    {
                        new Claim() {Date = DateTime.Parse("2013-08-10") },
                        new Claim() {Date = DateTime.Parse("2006-04-09") }
                    }
                },
                new Driver
                {
                    Name = "Bob Ross",
                    DateOfBirth = DateTime.Parse("1956-09-05"),
                    Occupation = context.Occupations.ToList()[1],
                    Claims = new List<Claim>()
                    {
                        new Claim() {Date = DateTime.Parse("2013-08-10") },
                        new Claim() {Date = DateTime.Parse("2014-08-10") },
                        new Claim() {Date = DateTime.Parse("2015-08-10") },
                    }
                },
                new Driver
                {
                    Name = "Corey Taylor",
                    DateOfBirth = DateTime.Parse("1987-03-02"),
                    Occupation = context.Occupations.ToList()[0],
                    Claims = new List<Claim>()
                    {
                        new Claim() {Date = DateTime.Parse("1992-06-29") },
                        new Claim() {Date = DateTime.Parse("2004-05-25") }
                    }
                },

                new Driver
                {
                    Name = "Ace Ventura",
                    DateOfBirth = DateTime.Parse("2005-01-02"),
                    Occupation = context.Occupations.ToList()[1],
                    Claims = new List<Claim>()
                    {
                    }
                },
            };
            context.Drivers.AddRange(defaultDrivers);
            context.SaveChanges();

            // Seed the policies.
            IList<Policy> defaultPolicies = new List<Policy>()
            {
                new Policy()
                {
                    StartDate = DateTime.Now.AddDays(2),
                    Drivers = new List<Driver>()
                    {
                        context.Drivers.ToList()[0]
                    },
                    
                }
            };
            context.Policies.AddRange(defaultPolicies);
            context.SaveChanges();

            // Seed the premiums.
            foreach (var policy in context.Policies)
                policy.Premium = premiumCalculator.CalculatePremium(policy);

            context.SaveChanges();

            base.Seed(context);
        }
    }
}
