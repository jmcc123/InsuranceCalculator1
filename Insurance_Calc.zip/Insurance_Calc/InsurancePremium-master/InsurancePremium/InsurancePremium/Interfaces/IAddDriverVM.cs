﻿using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace InsurancePremium.Interfaces
{
    public interface IAddDriverVM
    {
        string Name { get; set; }
        Occupation Occupation { get; set; }
        DateTime DateOfBirth { get; set; }
        ObservableCollection<Claim> Claims { get; }

        List<Occupation> Occupations { get; }
        DateTime ClaimDate { get; set; }

        ICommand AddClaimCmd { get; }
        ICommand SaveCmd { get; }
    }
}
