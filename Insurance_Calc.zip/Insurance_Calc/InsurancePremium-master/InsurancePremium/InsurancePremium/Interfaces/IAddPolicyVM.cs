﻿using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace InsurancePremium.Interfaces
{
    public interface IAddPolicyVM
    {
        DateTime StartDate { get; set; }
        ObservableCollection<Driver> AvailableDrivers { get; }
        ObservableCollection<Driver> DriversOnPolicy { get; }
        Driver SelectedDriver { get; set; }
        decimal Premium { get; }

        ICommand AddDriverCmd { get; }
        ICommand SaveCmd { get; }
    }
}
