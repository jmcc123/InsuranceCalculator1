﻿using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium.Interfaces
{
    interface IDeclinator
    {
        bool CalculateIsDeclined(Policy policy, ref string reason);
    }
}
