﻿using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium.Interfaces
{
    public interface IDeclinatorRule
    {
        /// <summary>
        /// Applies the rule to a given policy, and returns if the policy was delcined or not.
        /// </summary>
        /// <param name="policy">The policy to apply the rule to.</param>
        /// <param name="reason">The reason for declining the policy, if applicable.</param>
        /// <returns>True if the policy was declined.</returns>
        bool Apply(Policy policy, ref string reason);
    }
}
