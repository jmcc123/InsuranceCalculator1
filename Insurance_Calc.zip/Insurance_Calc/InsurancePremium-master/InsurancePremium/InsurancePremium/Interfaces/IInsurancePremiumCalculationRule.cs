﻿using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium.Interfaces
{
    public interface IInsurancePremiumCalculationRule
    {
        /// <summary>
        /// Applies the rule to the given policy, and returns the new premium.
        /// </summary>
        /// <param name="premium">The premium before the rule is applied.</param>
        /// <param name="policy">The policy to apply the premium to.</param>
        /// <returns>The premium after the rule has been applied</returns>
        decimal Apply(decimal premium, Policy policy);
    }
}
