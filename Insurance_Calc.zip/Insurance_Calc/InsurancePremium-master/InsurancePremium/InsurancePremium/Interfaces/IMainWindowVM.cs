﻿using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace InsurancePremium.Interfaces
{
    public interface IMainWindowVM
    {
        // Menu Binding Properties
        ICommand AddPolicyCmd { get; }
        ICommand AddDriverCmd { get; }

        // Policies Tab Binding Properties
        List<Policy> Policies { get;}
        Policy SelectedPolicy { get; }

        // Drivers Tab Binding Properties
        List<Driver> Drivers { get; }
        Driver SelectedDriver { get; }
    }
}
