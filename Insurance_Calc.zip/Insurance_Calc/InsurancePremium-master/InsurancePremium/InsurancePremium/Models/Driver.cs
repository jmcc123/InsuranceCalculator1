﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium.Models
{
    public class Driver
    {
        public int DriverId { get; set; }
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }

        public int OccupationId { get; set; }
        public virtual Occupation Occupation { get; set; }

        public virtual List<Claim> Claims { get; set; }
        public virtual List<Policy> Policies { get; set; }
    }
}
