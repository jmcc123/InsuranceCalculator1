﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremium.Models
{
    public class Policy
    {
        public int PolicyId { get; set; }
        public DateTime StartDate { get; set; }
        public decimal Premium { get; set; }
        public virtual List<Driver> Drivers { get; set; }
    }
}
