﻿using InsurancePremium;
using InsurancePremium.Interfaces;
using InsurancePremium.ViewModels;
using InsurancePremium.Views;
using SimpleInjector;
using SimpleInjector.Diagnostics;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


static class Program
{
    [STAThread]
    static void Main()
    {
        var container = Bootstrap();

        RunApplication(container);
    }

    private static Container Bootstrap()
    {
        var container = new Container();

        // Register the data context types.
        var reg = Lifestyle.Transient.CreateRegistration(typeof(InsurancePremiumContext), container);
        container.AddRegistration(typeof(InsurancePremiumContext), reg);
        reg.SuppressDiagnosticWarning(DiagnosticType.DisposableTransientComponent, "DbContext is short lived and disposed of.");
        container.Register<InsurancePremiumDBInitialiser>();

        // Register the view models (and nessesary views)
        container.Register<IMainWindowVM, MainWindowVM>();
        container.Register<IAddPolicyVM, AddPolicyVM>();
        container.Register<IAddDriverVM, AddDriverVM>();
        container.Register<AddPolicyView>();
        container.Register<AddDriverView>();

        // Register Funcs that act as factories.
        container.Register<Func<AddPolicyView>>(() => () => { return container.GetInstance<AddPolicyView>(); });
        container.Register<Func<AddDriverView>>(() => () => { return container.GetInstance<AddDriverView>(); });
        container.Register<Func<InsurancePremiumContext>>(() => () => { return container.GetInstance<InsurancePremiumContext>(); });

        // Register the calculator and declinator types.
        container.Register<IInsurancePremiumCalculatorFactory, InsurancePremiumCalculatorFactory>();
        container.Register<IDeclinatorFactory, DeclinatorFactory>();

        container.Register<IInsurancePremiumCalculator>(() =>
        {
            IInsurancePremiumCalculatorFactory factory = container.GetInstance<IInsurancePremiumCalculatorFactory>();
            return factory.Create();
        });
        container.Register<IDeclinator>(() =>
        {
            IDeclinatorFactory factory = container.GetInstance<IDeclinatorFactory>();
            return factory.Create();
        });

        container.Verify();

        return container;
    }

    private static void RunApplication(Container container)
    {
        try
        {
            App app = new App();
            MainWindow mainWindow = container.GetInstance<MainWindow>();
            app.Run(mainWindow);
        }
        catch(Exception e)
        {
            Console.WriteLine("Error starting application: {0}", e.Message);
            throw;
        }
    }
}

