﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;

namespace InsurancePremium.Rules.Declination
{
    /// <summary>
    /// Rule: If a driver has more than 2 claims, decline.
    /// </summary>
    public class MaxDriverClaimsRule : IDeclinatorRule
    {
        public bool Apply(Policy policy, ref string reason)
        {
            var badDrivers = policy.Drivers.Where(d => d.Claims.Count > 2).ToList();
            if(badDrivers.Count == 1)
            {
                reason = String.Format("Driver has more than 2 claims: {0:s}", badDrivers.First().Name);
                return true;
            }
            else if (badDrivers.Count > 1)
            {
                StringBuilder driverList = new StringBuilder("Drivers have more than 2 claims:");

                foreach (var driver in badDrivers)
                    driverList.AppendLine("\t" + driver.Name);

                reason = driverList.ToString();
                return true;
            }

            return false;
        }
    }


}
