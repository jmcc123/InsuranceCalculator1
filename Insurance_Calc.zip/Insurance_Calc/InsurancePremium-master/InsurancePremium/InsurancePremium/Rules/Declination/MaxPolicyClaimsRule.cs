﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;

namespace InsurancePremium.Rules.Declination
{
    public class MaxPolicyClaimsRule : IDeclinatorRule
    {
        /// <summary>
        /// Rule: If the total number of claims exceeds 3, decline.
        /// </summary>
        public MaxPolicyClaimsRule()
        {
        }

        public bool Apply(Policy policy, ref string reason)
        {
            if(policy.Drivers.Sum(d => d.Claims.Count) > 3)
            {
                reason = "Policy has more than 3 claims.";
                return true;
            }

            return false;
        }
    }
}
