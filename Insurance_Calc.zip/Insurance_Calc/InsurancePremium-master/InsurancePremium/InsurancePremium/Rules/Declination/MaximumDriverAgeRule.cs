﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;

namespace InsurancePremium.Rules.Declination
{
    public class MaximumDriverAgeRule : IDeclinatorRule
    {
        public MaximumDriverAgeRule()
        {
        }

        public bool Apply(Policy policy, ref string reason)
        {
            Driver eldestDriver = policy.Drivers.OrderBy(d => d.DateOfBirth)
                .First();

            if (policy.StartDate.Subtract(eldestDriver.DateOfBirth).TotalYears() > 75)
            {
                reason = String.Format("Age of Oldest Driver: {0:s}", eldestDriver.Name);
                return true;
            }

            return false;
        }
    }
}
