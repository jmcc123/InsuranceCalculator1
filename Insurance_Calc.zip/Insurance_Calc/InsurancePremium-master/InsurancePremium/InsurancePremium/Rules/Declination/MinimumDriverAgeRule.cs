﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;

namespace InsurancePremium.Rules.Declination
{
    public class MinimumDriverAgeRule : IDeclinatorRule
    {
        /// <summary>
        /// Rule: If the youngest driver is under the age of 21 at the start date of the policy, decline.
        /// </summary>
        public MinimumDriverAgeRule()
        {
        }

        public bool Apply(Policy policy, ref string reason)
        {

            Driver youngestDriver = policy.Drivers.OrderByDescending(d => d.DateOfBirth)
                .First();

            if(policy.StartDate.Subtract(youngestDriver.DateOfBirth).TotalYears() < 21)
            {
                reason = String.Format("Age of Youngest Driver: {0:s}", youngestDriver.Name);
                return true;
            }

            return false;
        }
    }
}
