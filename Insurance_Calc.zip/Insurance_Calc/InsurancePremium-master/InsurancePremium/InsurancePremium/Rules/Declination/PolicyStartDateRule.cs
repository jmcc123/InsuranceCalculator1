﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;

namespace InsurancePremium.Rules.Declination
{
    public class PolicyStartDateRule : IDeclinatorRule
    {
        /// <summary>
        /// Rule: If the start date of the policy is before today, decline.
        /// </summary>
        public PolicyStartDateRule()
        {
        }

        public bool Apply(Policy policy, ref string reason)
        {
            if(policy.StartDate.Date > DateTime.Now.Date)
            {
                reason = "Start Date of Policy";
                return true;
            }

            return false;
        }
    }
}
