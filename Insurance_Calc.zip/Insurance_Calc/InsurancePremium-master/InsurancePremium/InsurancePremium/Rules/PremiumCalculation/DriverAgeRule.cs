﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;
using InsurancePremium;

namespace InsurancePremium.Rules.PremiumCalculation
{
    public class DriverAgeRule : IInsurancePremiumCalculationRule
    {
        /// <summary>
        /// Rule: If the youngest driver is aged between 21 and 25 (inclusive) at policy start, increase premium by 20%.
        /// Then: If the youngest driver is aged between 26 and 75 (inclusive) at policy start, decrease premium by 10%
        /// </summary>
        public DriverAgeRule()
        {
        }

        public decimal Apply(decimal premium, Policy policy)
        {
            if (anyDriverAgedBetweenXAndYAtStartDate(policy, 21, 25))
                 return premium *= 1.2m;

            if (anyDriverAgedBetweenXAndYAtStartDate(policy, 26, 75))
                return premium *= 0.9m;

            return premium;
        }

        private bool anyDriverAgedBetweenXAndYAtStartDate(Policy policy, int x, int y)
        {
            return policy.Drivers.Any((d) =>
            {
                int ageAtStart = (int)(policy.StartDate.Subtract(d.DateOfBirth).TotalYears());
                return ageAtStart >= x && ageAtStart <= y;
            });
        }
    }
}
