﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;

namespace InsurancePremium.Rules.PremiumCalculation
{
    public class DriverOccupationRule : IInsurancePremiumCalculationRule
    {
        // Backing Fields
        private readonly int chauffeurId;
        private readonly int accountantId;

        // Properties
        public int ChauffeurId { get { return chauffeurId; } }
        public int AccountantId { get { return accountantId; } }

        /// <summary>
        /// Rule: If there is a driver who is a Chauffer, increase premium by 10%.
        /// Next: If there is a driver who is an accountant, decrease the preimum by 10%.
        /// </summary>
        /// <param name="chauffeurId">The OccupationId of 'Chauffeur' in the DB.</param>
        /// <param name="accountantId">The OccupationId of 'Accountant' in the DB.</param>
        public DriverOccupationRule(int chauffeurId, int accountantId)
        {
            this.chauffeurId = chauffeurId;
            this.accountantId = accountantId;
        }

        public decimal Apply(decimal premium, Policy policy)
        {
            if (policy.Drivers.Any(d => d.OccupationId == ChauffeurId))
                premium *= 1.1m;

            if (policy.Drivers.Any(d => d.OccupationId == AccountantId))
                premium *= 0.9m;

            return premium;
        }
    }
}
