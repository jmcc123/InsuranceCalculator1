﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;
using System.Windows.Input;
using System.Collections.ObjectModel;
using Microsoft.Practices.Prism.Mvvm;
using Microsoft.Practices.Prism.Commands;
using InsurancePremium.Views;
using System.Windows;

namespace InsurancePremium.ViewModels
{
    class AddDriverVM : BindableBase, IAddDriverVM
    {
        // Backing Fields
        private readonly Func<InsurancePremiumContext> dbContextFactory;
        private List<Occupation> occupations;
        private DateTime claimDate;

        private ObservableCollection<Claim> claims;
        private DateTime dateOfBirth;
        private string name;
        private Occupation occupation;

        private readonly DelegateCommand addClaimCmd;
        private readonly DelegateCommand saveCmd;

        // Properties
        public ICommand AddClaimCmd { get { return addClaimCmd; } }
        public ICommand SaveCmd { get { return saveCmd; } }

        public ObservableCollection<Claim> Claims
        {
            get { return claims; }
            private set
            {
                SetProperty(ref claims, value);
                saveCmd.RaiseCanExecuteChanged();
            }
        }

        public DateTime DateOfBirth
        {
            get { return dateOfBirth; }
            set { SetProperty(ref dateOfBirth, value); }
        }

        public string Name
        {
            get { return name; }
            set
            {
                SetProperty(ref name, value);
                saveCmd.RaiseCanExecuteChanged();
            }
        }

        public Occupation Occupation
        {
            get { return occupation; }
            set
            {
                SetProperty(ref occupation, value);
                saveCmd.RaiseCanExecuteChanged();
            }
        }

        public List<Occupation> Occupations
        {
            get { return occupations; }
            set { SetProperty(ref occupations, value); }
        }

        public DateTime ClaimDate
        {
            get { return claimDate; }
            set { SetProperty(ref claimDate, value); }
        }

        public AddDriverVM(Func<InsurancePremiumContext> dbContextFactory)
        {
            this.dbContextFactory = dbContextFactory;
            this.addClaimCmd = new DelegateCommand(AddClaim, CanAddClaim);
            this.saveCmd = new DelegateCommand(Save, CanSave);

            this.DateOfBirth = DateTime.Parse("1990-01-01");
            this.claimDate = DateTime.Now;

            using (InsurancePremiumContext db = dbContextFactory.Invoke())
            {
                Occupations = db.Occupations.ToList();
                Claims = new ObservableCollection<Claim>();
            }
        }

        private void AddClaim()
        {
            Claims.Add(new Claim { Date = ClaimDate });
            saveCmd.RaiseCanExecuteChanged();
        }

        private bool CanAddClaim()
        {
            return Claims.Count < 5 && ClaimDate.Date <= DateTime.Now.Date;
        }

        private void Save()
        {
            using (InsurancePremiumContext db = dbContextFactory.Invoke())
            {
                db.Occupations.Attach(Occupation);

                Driver driver = new Driver()
                {
                    Name = Name,
                    Occupation = Occupation,
                    DateOfBirth = DateOfBirth,
                    Claims = Claims.ToList()
                };

                db.Drivers.Add(driver);
                db.SaveChanges();

                AddDriverView win = Application.Current.Windows.OfType<AddDriverView>().First();
                win.Close();
            }
        }

        private bool CanSave()
        {
            return !String.IsNullOrWhiteSpace(Name) &&
                Occupation != null &&
                Claims.Count <= 5;
        }

    }
}
