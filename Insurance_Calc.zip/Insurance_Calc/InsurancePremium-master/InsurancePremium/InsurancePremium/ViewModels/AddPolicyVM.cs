﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InsurancePremium.Models;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Mvvm;
using System.Windows;
using InsurancePremium.Views;

namespace InsurancePremium.ViewModels
{
    class AddPolicyVM : BindableBase, IAddPolicyVM
    {
        // Backing fields.
        private readonly ObservableCollection<Driver> availableDrivers;
        private readonly ObservableCollection<Driver> driversOnPolicy;
        private readonly DelegateCommand saveCmd;
        private readonly DelegateCommand addDriverCmd;
        private DateTime startDate;
        private Driver selectedDriver;
        private decimal premium;

        private readonly Func<InsurancePremiumContext> dbContextFactory;
        private readonly IDeclinator declinator;
        private readonly IInsurancePremiumCalculator premiumCalculator;

        public ObservableCollection<Driver> AvailableDrivers { get { return availableDrivers; } }
        public ObservableCollection<Driver> DriversOnPolicy { get { return driversOnPolicy; } }
        public ICommand SaveCmd { get { return saveCmd; } }
        public ICommand AddDriverCmd { get { return addDriverCmd; } }

        public DateTime StartDate
        {
            get { return startDate; }
            set
            {
                SetProperty(ref startDate, value);
                saveCmd.RaiseCanExecuteChanged();
            }
        }

        public Driver SelectedDriver
        {
            get { return selectedDriver; }
            set { SetProperty(ref selectedDriver, value); }
        }

        public decimal Premium
        {
            get { return premium; }
            set { SetProperty(ref premium, value); }
        }

        public AddPolicyVM(Func<InsurancePremiumContext> dbContextFactory, IDeclinator declinator, IInsurancePremiumCalculator premiumCalculator)
        {
            this.dbContextFactory = dbContextFactory;
            this.declinator = declinator;
            this.premiumCalculator = premiumCalculator;
            this.driversOnPolicy = new ObservableCollection<Driver>();

            using (InsurancePremiumContext db = dbContextFactory.Invoke())
            {
                this.availableDrivers = new ObservableCollection<Driver>(db.Drivers.Include("Claims").ToList());

                this.saveCmd = new DelegateCommand(Save, CanSave);
                this.addDriverCmd = new DelegateCommand(AddDriver, CanAddDriver);

                this.StartDate = DateTime.Now;

                if (availableDrivers.Count > 0)
                    SelectedDriver = AvailableDrivers[0];
            }
        }

        private void AddDriver()
        {
            DriversOnPolicy.Add(SelectedDriver);
            AvailableDrivers.Remove(SelectedDriver);

            Premium = premiumCalculator.CalculatePremium(new Policy()
            {
                StartDate = StartDate,
                Drivers = DriversOnPolicy.ToList()
            });

            saveCmd.RaiseCanExecuteChanged();

            if (AvailableDrivers.Count >= 1)
                SelectedDriver = AvailableDrivers[0];
        }

        private bool CanAddDriver()
        {
            return DriversOnPolicy.Count < 5;
        }

        private void Save()
        {
            Policy policy = new Policy()
            {
                StartDate = StartDate,
                Drivers = DriversOnPolicy.ToList(),
                Premium = Premium
            };

            string errorMessage = null;
            if (declinator.CalculateIsDeclined(policy, ref errorMessage))
            {
                MessageBox.Show(errorMessage, "Policy Declined", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                using (InsurancePremiumContext db = dbContextFactory.Invoke())
                {
                    // Attach the drivers.
                    foreach (var driver in policy.Drivers)
                        db.Drivers.Attach(driver);

                    db.Policies.Add(policy);
                    db.SaveChanges();
                }
            }

            AddPolicyView win = Application.Current.Windows.OfType<AddPolicyView>().First();
            win.Close();
        }

        private bool CanSave()
        {
            return driversOnPolicy.Count >= 1 && driversOnPolicy.Count <= 5;
        }
    }
}
