﻿using InsurancePremium.Interfaces;
using InsurancePremium.Models;
using InsurancePremium.Views;
using Microsoft.Practices.Prism.Commands;
using Microsoft.Practices.Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace InsurancePremium.ViewModels
{
    class MainWindowVM : BindableBase, IMainWindowVM
    {
        // Backing Fields
        private readonly Func<InsurancePremiumContext> dbContextFactory;
        private readonly Func<AddDriverView> addDriverViewFactroy;
        private readonly Func<AddPolicyView> addPolicyViewFactory;
        private readonly ICommand addPolicyCmd;
        private readonly ICommand addDriverCmd;
        private List<Policy> policies;
        private List<Driver> drivers;
        private Policy selectedPolicy;
        private Driver selectedDriver;
        
        
        public List<Policy> Policies
        {
            get { return policies; }
            private set { SetProperty(ref policies, value); }
        }

        public List<Driver> Drivers
        {
            get { return drivers; }
            private set { SetProperty(ref drivers, value); }
        }

        public Policy SelectedPolicy
        {
            get { return selectedPolicy; }
            set { SetProperty(ref selectedPolicy, value); }
        }

        public Driver SelectedDriver
        {
            get { return selectedDriver; }
            set { SetProperty(ref selectedDriver, value); }
        }

        public ICommand AddPolicyCmd
        {
            get { return addPolicyCmd; }
        }

        public ICommand AddDriverCmd
        {
            get { return addDriverCmd; }
        }

        public MainWindowVM(Func<InsurancePremiumContext> dbContextFactory,Func<AddPolicyView> addPolicyViewFactory, Func<AddDriverView> addDriverViewFactroy)
        {
            this.dbContextFactory = dbContextFactory;
            this.addPolicyViewFactory = addPolicyViewFactory;
            this.addDriverViewFactroy = addDriverViewFactroy;
            this.addPolicyCmd = new DelegateCommand(AddPolicy);
            this.addDriverCmd = new DelegateCommand(AddDriver);
            this.ReloadData();
        }

        private void ReloadData()
        {
            using (InsurancePremiumContext db = dbContextFactory.Invoke())
            {
                Drivers = db.Drivers.Include("Claims").Include("Occupation").ToList();
                Policies = db.Policies.Include("Drivers").ToList();

                SelectedPolicy = Policies.Count > 0 ? Policies[0] : null;
                SelectedDriver = Drivers.Count > 0 ? Drivers[0] : null;
            }
        }

        private void AddDriver()
        {
            AddDriverView view = addDriverViewFactroy.Invoke();
            view.ShowDialog();
            ReloadData();
        }

        private void AddPolicy()
        {
            AddPolicyView view = addPolicyViewFactory.Invoke();
            view.ShowDialog();
            ReloadData();
        }

    }
}
