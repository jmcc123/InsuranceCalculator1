﻿using InsurancePremium.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace InsurancePremium.Views
{
    /// <summary>
    /// Interaction logic for AddPolicyView.xaml
    /// </summary>
    public partial class AddPolicyView : Window
    {
        public AddPolicyView(IAddPolicyVM viewModel)
        {
            DataContext = viewModel;
            InitializeComponent();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
