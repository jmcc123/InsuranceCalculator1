﻿using InsurancePremium.Interfaces;
using InsurancePremium.Models;
using InsurancePremium.Rules.Declination;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremiumTests
{
    [TestClass]
    public class PolicyDeclinationTests
    {
        private const int CHAUFFEUR_OCCUPATION_ID = 1;
        private const int ACCOUNTANT_OCCUPATION_ID = 2;

        private TestInsurancePremiumContext db;

        [TestInitialize]
        public void SetUp()
        {
            db = new TestInsurancePremiumContext(new TestInsurancePremiumDBInitialiser());
        }

        [TestCleanup]
        public void CleanUp()
        {
            db.Dispose();
        }

        [TestMethod]
        public void PolicyDeclination_PolicyStartDate_Future()
        {
            IDeclinatorRule rule = new PolicyStartDateRule();
            Policy policy = new Policy()
            {
                StartDate = DateTime.Now.AddDays(2),
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(30 * 365))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            string errorMessage = null;
            bool declined = rule.Apply(policy, ref errorMessage);
            Assert.IsTrue(declined);
            Assert.AreEqual("Start Date of Policy", errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_PolicyStartDate_Past()
        {
            IDeclinatorRule rule = new PolicyStartDateRule();
            Policy policy = new Policy()
            {
                StartDate = DateTime.Now.Subtract(TimeSpan.FromDays(2)),
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(30 * 365))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            string errorMessage = null;
            bool declined = rule.Apply(policy, ref errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MinimumAge_20()
        {
            string errorMessage = null;
            bool declined = youngestDriver(20, out errorMessage);
            Assert.IsTrue(declined);
            Assert.AreEqual("Age of Youngest Driver: John Smith", errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MinimumAge_21()
        {
            string errorMessage = null;
            bool declined = youngestDriver(21, out errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MinimumAge_22()
        {
            string errorMessage = null;
            bool declined = youngestDriver(22, out errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        private bool youngestDriver(int age, out string errorMessage)
        {
            IDeclinatorRule rule = new MinimumDriverAgeRule();
            Policy policy = new Policy()
            {
                StartDate = DateTime.Now,
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(age * 365.2425))
                    },
                    new Driver
                    {
                        Name = "Corey Taylor",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(30 * 365.2425))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            errorMessage = null;
            return rule.Apply(policy, ref errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxiumAge_76()
        {
            string errorMessage = null;
            bool declined = eldestDriver(76, out errorMessage);
            Assert.IsTrue(declined);
            Assert.AreEqual("Age of Oldest Driver: John Smith", errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxiumAge_75()
        {
            string errorMessage = null;
            bool declined = eldestDriver(75, out errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxiumAge_74()
        {
            string errorMessage = null;
            bool declined = eldestDriver(74, out errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        private bool eldestDriver(int age, out string errorMessage)
        {
            IDeclinatorRule rule = new MaximumDriverAgeRule();
            Policy policy = new Policy()
            {
                StartDate = DateTime.Now,
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(age * 365.2425))
                    },
                    new Driver
                    {
                        Name = "Corey Taylor",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(30 * 365.2425))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            errorMessage = null;
            return rule.Apply(policy, ref errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxDriverClaims_2()
        {
            string errorMessage = null;
            bool declined = ClaimTest(new MaxDriverClaimsRule(), 2, 0, out errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxDriverClaims_3()
        {
            string errorMessage = null;
            bool declined = ClaimTest(new MaxDriverClaimsRule(), 3, 0, out errorMessage);
            Assert.IsTrue(declined);
            Assert.AreEqual("Driver has more than 2 claims: John Smith", errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxPolicyClaims_1_1()
        {
            string errorMessage = null;
            bool declined = ClaimTest(new MaxPolicyClaimsRule(), 1, 1, out errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxPolicyClaims_2_1()
        {
            string errorMessage = null;
            bool declined = ClaimTest(new MaxPolicyClaimsRule(), 2, 1, out errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxPolicyClaims_1_2()
        {
            string errorMessage = null;
            bool declined = ClaimTest(new MaxPolicyClaimsRule(), 1, 2, out errorMessage);
            Assert.IsFalse(declined);
            Assert.IsNull(errorMessage);
        }

        [TestMethod]
        public void PolicyDeclination_MaxPolicyClaims_2_2()
        {
            string errorMessage = null;
            bool declined = ClaimTest(new MaxPolicyClaimsRule(), 2, 2, out errorMessage);
            Assert.IsTrue(declined);
            Assert.AreEqual("Policy has more than 3 claims.", errorMessage);
        }

        private bool ClaimTest(IDeclinatorRule rule, int n, int m, out string errorMessage)
        {

            List<Claim> claims1 = new List<Claim>();
            List<Claim> claims2 = new List<Claim>();
            Random rand = new Random();

            for (int i = 0; i < n; i++)
                claims1.Add(new Claim() { Date = DateTime.Now.Subtract(TimeSpan.FromDays(rand.NextDouble() * 365)) });

            for (int i = 0; i < m; i++)
                claims2.Add(new Claim() { Date = DateTime.Now.Subtract(TimeSpan.FromDays(rand.NextDouble() * 365)) });

            Policy policy = new Policy()
            {
                StartDate = DateTime.Now,
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = claims1,
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(40 * 365.2425))
                    },
                    new Driver
                    {
                        Name = "Corey Taylor",
                        Claims = claims2,
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(30 * 365.2425))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            errorMessage = null;
            return rule.Apply(policy, ref errorMessage);
        }
    }
}
