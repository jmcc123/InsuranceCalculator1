﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using InsurancePremium;
using InsurancePremium.Interfaces;
using InsurancePremium.Rules.PremiumCalculation;
using InsurancePremium.Models;
using System.Collections.Generic;

namespace InsurancePremiumTests
{
    [TestClass]
    public class PremiumCalculationTests
    {
        private const int CHAUFFEUR_OCCUPATION_ID = 1;
        private const int ACCOUNTANT_OCCUPATION_ID = 2;

        private TestInsurancePremiumContext db;

        [TestInitialize]
        public void SetUp()
        {
            db = new TestInsurancePremiumContext(new TestInsurancePremiumDBInitialiser());
        }

        [TestCleanup]
        public void CleanUp()
        {
            db.Dispose();
        }

        [TestMethod]
        public void PremiumCalc_DriverOccupation_Chaffeur()
        {
            IInsurancePremiumCalculationRule rule = new DriverOccupationRule(CHAUFFEUR_OCCUPATION_ID, ACCOUNTANT_OCCUPATION_ID);
            Policy policy = new Policy()
            {
                StartDate = DateTime.Now,
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(30 * 365))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            decimal premium = rule.Apply(100m, policy);
            Assert.AreEqual(110m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverOccupation_Accountant()
        {
            IInsurancePremiumCalculationRule rule = new DriverOccupationRule(CHAUFFEUR_OCCUPATION_ID, ACCOUNTANT_OCCUPATION_ID);
            Policy policy = new Policy()
            {
                StartDate = DateTime.Now,
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = new List<Claim>(),
                        OccupationId = 2,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(30 * 365))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            decimal premium = rule.Apply(100m, policy);
            Assert.AreEqual(90m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverAge_21_Single()
        {
            var premium = AgeTestSingle(21);
            Assert.AreEqual(120m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverAge_25_Single()
        {
            var premium = AgeTestSingle(25);
            Assert.AreEqual(120m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverAge_26_Single()
        {
            var premium = AgeTestSingle(26);
            Assert.AreEqual(90m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverAge_75_Single()
        {
            var premium = AgeTestSingle(75);
            Assert.AreEqual(90m, premium);
        }

        private decimal AgeTestSingle(int age)
        {
            IInsurancePremiumCalculationRule rule = new DriverAgeRule();
            Policy policy = new Policy()
            {
                StartDate = DateTime.Now,
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(age * 365.2425))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            return rule.Apply(100m, policy);
        }

        [TestMethod]
        public void PremiumCalc_DriverAge_21_Multiple()
        {
            var premium = AgeTestMultiple(21);
            Assert.AreEqual(120m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverAge_25_Multiple()
        {
            var premium = AgeTestMultiple(25);
            Assert.AreEqual(120m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverAge_26_Multiple()
        {
            var premium = AgeTestMultiple(26);
            Assert.AreEqual(90m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverAge_75_Multiple()
        {
            var premium = AgeTestMultiple(75);
            Assert.AreEqual(90m, premium);
        }

        private decimal AgeTestMultiple(int age)
        {
            IInsurancePremiumCalculationRule rule = new DriverAgeRule();
            Policy policy = new Policy()
            {
                StartDate = DateTime.Now,
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(age * 365.2425))
                    },
                    new Driver
                    {
                        Name = "The Doctor",
                        Claims = new List<Claim>(),
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(40 * 365.2425))
                    }
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            return rule.Apply(100m, policy);
        }

        [TestMethod]
        public void PremiumCalc_DriverClaims_Within1Year_1()
        {
            var premium = ClaimTest(1, 0);
            Assert.AreEqual(120m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverClaims_Within1Year_5()
        {
            var premium = ClaimTest(5, 0);
            Assert.AreEqual(200m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverClaims_Within5Years_1()
        {
            var premium = ClaimTest(0, 1);
            Assert.AreEqual(110m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverClaims_Within5Years_5()
        {
            var premium = ClaimTest(0, 5);
            Assert.AreEqual(150m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverClaims_Mix_1_1()
        {
            var premium = ClaimTest(1, 1);
            Assert.AreEqual(130m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverClaims_Mix_2_3()
        {
            var premium = ClaimTest(2, 3);
            Assert.AreEqual(170m, premium);
        }

        [TestMethod]
        public void PremiumCalc_DriverClaims_Mix_3_2()
        {
            var premium = ClaimTest(3, 2);
            Assert.AreEqual(180m, premium);
        }

        private decimal ClaimTest(int n, int m)
        {
            IInsurancePremiumCalculationRule rule = new DriverClaimsRule();

            List<Claim> claims = new List<Claim>();
            Random rand = new Random();

            for (int i = 0; i < n; i++)
                claims.Add(new Claim() { Date = DateTime.Now.Subtract(TimeSpan.FromDays(rand.NextDouble() * 365)) });

            for (int i = 0; i < m; i++)
                claims.Add(new Claim() { Date = DateTime.Now.Subtract(TimeSpan.FromDays(365.2425 + rand.NextDouble()*365*4)) });

            Policy policy = new Policy()
            {
                StartDate = DateTime.Now,
                Drivers = new List<Driver>()
                {
                    new Driver
                    {
                        Name = "John Smith",
                        Claims = claims,
                        OccupationId = 1,
                        DateOfBirth = DateTime.Now.Subtract(TimeSpan.FromDays(40 * 365.2425))
                    },
                }
            };

            db.Policies.Add(policy);
            db.SaveChanges();

            return rule.Apply(100m, policy);
        }
    }
}
