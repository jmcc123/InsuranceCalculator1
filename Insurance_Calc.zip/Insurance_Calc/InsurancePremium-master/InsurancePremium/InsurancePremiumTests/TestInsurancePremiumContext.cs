﻿using InsurancePremium;
using InsurancePremium.Interfaces;
using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremiumTests
{
    class TestInsurancePremiumContext : InsurancePremiumContextAbstract
    {
        public TestInsurancePremiumContext(DropCreateDatabaseAlways<TestInsurancePremiumContext> initialiser) :
            base("name=InsurancePremiumTestDB")
        {
            Database.SetInitializer(initialiser);
        }
    }
}
