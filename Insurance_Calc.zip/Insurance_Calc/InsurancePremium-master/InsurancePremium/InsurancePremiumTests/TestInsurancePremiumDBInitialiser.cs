﻿using InsurancePremium;
using InsurancePremium.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InsurancePremiumTests
{
    class TestInsurancePremiumDBInitialiser : DropCreateDatabaseAlways<TestInsurancePremiumContext>
    {
        private const int CHAUFFEUR_OCCUPATION_ID = 1;
        private const int ACCOUNTANT_OCCUPATION_ID = 2;

        protected override void Seed(TestInsurancePremiumContext context)
        {
            // Seed the occupations.
            IList<Occupation> defaultOccupations = new List<Occupation>()
            {
                new Occupation { OccupationId = CHAUFFEUR_OCCUPATION_ID, Name = "Chauffeur" },
                new Occupation { OccupationId = ACCOUNTANT_OCCUPATION_ID, Name = "Accountant" }
            };
            context.Occupations.AddRange(defaultOccupations);
            context.SaveChanges();

            base.Seed(context);
        }
    }
}
