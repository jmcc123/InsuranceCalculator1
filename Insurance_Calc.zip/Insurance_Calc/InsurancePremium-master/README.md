# InsurancePremium

A simple insurance premium calculation system. Requires:
- Visual Studio 2015 CE
- .Net Framework 4.5.2
- Ability to download Nuget packages in VS.
