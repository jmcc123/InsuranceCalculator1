﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insurance_Calc
{
    public static class Helper
    {
        public static double TotalYears(this TimeSpan timeSpan)
        {
            return timeSpan.TotalDays / 365.2425;
        }

        public static int policyStartPrice = 500;
    }
}
