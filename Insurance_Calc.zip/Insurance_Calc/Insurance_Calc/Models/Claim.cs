﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insurance_Calc.Models
{
    public class Claim
    {
        public int ClaimId { get; set; }
        public DateTime Date { get; set; }

        public int DriverId { get; set; }
        public Driver Driver { get; set; }

       

    }
}
