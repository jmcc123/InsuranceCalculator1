﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insurance_Calc.Models
{
    public class Driver
    {
        public int DriverId { get; set; }
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }

        public int OccupationId { get; set; }
       

        public List<Claim> Claims { get; set; }
       
    }
}
