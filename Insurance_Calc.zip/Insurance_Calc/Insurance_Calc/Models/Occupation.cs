﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Insurance_Calc.Models
{
    //holds list of all occupations
    public class Occupation
    {
        public List<string> jobs(){
            List<string> joblist = new List<string>();
            joblist.Add("2_ACCOUNTANT");
            joblist.Add("1_CHAUFFER");
            return joblist;
        }
      
        
        

    }

    
}
