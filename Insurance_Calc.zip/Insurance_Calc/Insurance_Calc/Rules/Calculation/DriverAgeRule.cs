﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Insurance_Calc.Models;
using Insurance_Calc;

namespace Insurance_Calc.Rules.Calculation
{
    public class DriverAgeRule
    {
        public decimal ageRules( Policy policy)
        {
            decimal premium = policy.Premium;

            if (anyDriverAgedBetween(policy, 21, 25) == true)
            {
                return premium *= 1.2m;
            }
            else if (anyDriverAgedBetween(policy, 26, 75) == true)
            {
                return premium *= 0.9m;
                
            }
            else
            {
                return premium;
            }
        }

        private bool anyDriverAgedBetween(Policy policy, int start, int end)
        {

             policy.Drivers.Any((d) =>
            {
                int ageAtStart = (int)(policy.StartDate.Subtract(d.DateOfBirth).TotalYears());
                if (ageAtStart >= start && ageAtStart <= end)
                {
                    return true;
                }
                else return false;
            });

             return false;
        }
    }
}
