﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Insurance_Calc.Models;

/// <summary>
/// Rule: For each claim within 1 year of the start date, increase the premium by 20%.
/// Then: For each claim withim 2 to 5 years of the start dtae, increase the premium by 10%.
/// </summary>
/// 
namespace Insurance_Calc.Rules.Calculation
{
    public class DriverClaimsRule
    {
        public decimal claimsrules( Policy policy)
        {
            decimal premium = policy.Premium;
            decimal modifier = 1;

            int claimsWithin1Year = policy.Drivers.SelectMany(d => d.Claims)
                .Where(c => policy.StartDate.Subtract(c.Date).TotalYears() < 1)
                .Count();

            modifier += 0.2m * claimsWithin1Year;

            int claimsWithin2To5Years = policy.Drivers.SelectMany(d => d.Claims)
                .Where(c => policy.StartDate.Subtract(c.Date).TotalYears() < 5)
                .Count() - claimsWithin1Year;

            modifier += 0.1m * claimsWithin2To5Years;

            return premium * modifier;
        }
    }
}
