﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Insurance_Calc.Models;

namespace Insurance_Calc.Rules.Calculation
{
    /// <summary>
    /// Rule: If there is a driver who is a Chauffer, increase premium by 10%.
    /// Next: If there is a driver who is an accountant, decrease the preimum by 10%.
    /// </summary>
    public class DriverOccupationRule
    {
       
        //1 = Chauffeur
        //2 = Accountant

        public decimal occupationrules( Policy policy)
        {
            decimal premium = policy.Premium;
            if (policy.Drivers.Any(d => d.OccupationId.ToString() == "1"))
                premium *= 1.1m;

            if (policy.Drivers.Any(d => d.OccupationId.ToString() == "2"))
                premium *= 0.9m;

            return premium;
        }
    }
}
