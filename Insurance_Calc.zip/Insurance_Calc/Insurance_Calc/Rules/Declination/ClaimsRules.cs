﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Insurance_Calc.Models;

namespace Insurance_Calc.Rules.Delination

      /// <summary>
    /// Rule: If a driver has more than 2 claims, decline.
    /// </summary>
{
    class ClaimsRules
    {
        public string DriverClaimAmount(Driver driver)
        {
            try
            {
                int claimcnt = driver.Claims.Count;

                if (claimcnt == 5)
                {
                    return "Maximum Claims Assigned for Driver";
                }
                return "pass";
            }
            catch (Exception e)
            {
                return "pass";
            }
         
            
        }

        public string DriverClaims(Policy policy)
        {
            var badDrivers = policy.Drivers.Where(d => d.Claims.Count > 2).ToList();
            if (badDrivers.Count == 1)
            {
                string reason = String.Format("Driver has more than 2 claims: {0:s}", badDrivers.First().Name);
                return reason;
            }
            else if (badDrivers.Count > 1)
            {
                StringBuilder driverList = new StringBuilder("Drivers have more than 2 claims:");

                foreach (var driver in badDrivers)
                    driverList.AppendLine("\t" + driver.Name);

                string reason = driverList.ToString();
                return reason;
            }

            return "pass";
        }

        public string PolicyClaims(Policy policy) 
        {
            if (policy.Drivers.Sum(d => d.Claims.Count) > 3)
            {
                string reason = "Policy has more than 3 claims.";
                return reason;
            }

            return "pass";
        }
    }
}
