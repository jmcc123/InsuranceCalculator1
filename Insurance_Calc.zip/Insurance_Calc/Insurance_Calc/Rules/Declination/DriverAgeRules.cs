﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Insurance_Calc.Models;

namespace Insurance_Calc.Rules.Delination
{
    public class DriverAgeRules
    {
        public bool agerules(Policy policy, ref string reason)
        {
            //this will compute all the age rules associated with the system

            //Oldest Driver over 75
            Driver eldestDriver = policy.Drivers.OrderBy(d => d.DateOfBirth).First();

            if (policy.StartDate.Subtract(eldestDriver.DateOfBirth).TotalYears() > 75)
            {
                reason = String.Format("Age of Oldest Driver {0:s}", eldestDriver.Name);
                return true;
            }
           
            
            //youngest Driver under 21
            Driver yougestDriver = policy.Drivers.OrderBy(d => d.DateOfBirth).Last();
            if (policy.StartDate.Subtract(eldestDriver.DateOfBirth).TotalYears() < 21)
            {
                reason = String.Format("Age of Youngest Driver {0:s}", eldestDriver.Name);
                return true;
            }

            return false;
        }
    }

   
}
