﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Insurance_Calc.Models;

namespace Insurance_Calc.Rules.Declination
{
    class DriverAmountsRules
    {
        public string AmountRules(Policy policy)
        {
            string reason = string.Empty;

            try
            {
                int driveramount = policy.Drivers.Count;

                if (driveramount == 5)
                {
                    reason = "Maximum Drivers on Policy";
                    return reason;
                }
                else
                {
                    return reason = "pass";
                }
            
            }
            catch(Exception e){
                //do nothing
            }
            return reason = "pass";
                
           
           
        }
    }
}
