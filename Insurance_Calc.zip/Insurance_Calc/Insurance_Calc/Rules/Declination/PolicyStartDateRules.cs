﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Insurance_Calc.Models;

namespace Insurance_Calc.Rules.Delination
{
    public class PolicyStartDateRules
    {
        public bool DateRules(Policy policy, ref string reason)
        {
            if (policy.StartDate.Date < DateTime.Now.Date)
            {
                reason = "Start Date of Policy";
                return true;
            }

            return false;
        }
    }
}
