﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Insurance_Calc.Models;

namespace Insurance_Calc
{
    public partial class frm_Main : Form
    {
        public frm_Main()
        {
            InitializeComponent();
            
        }

        frm_addPolicy policynew;
        public void newPolicyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (policynew == null)
            {
               

                policynew = new frm_addPolicy();
                policynew.MdiParent = this;
                policynew.Show();
            }
            else
            {
                policynew.Activate();
            }

        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
