﻿namespace Insurance_Calc
{
    partial class frm_addDriver
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtbox_DName = new System.Windows.Forms.TextBox();
            this.lbl_Occupation = new System.Windows.Forms.Label();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.dtp_DOB = new System.Windows.Forms.DateTimePicker();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.dtp_AddClaim = new System.Windows.Forms.DateTimePicker();
            this.btn_addclaim = new System.Windows.Forms.Button();
            this.dtg_claims = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClaimDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtbox_occupation = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_claims)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // txtbox_DName
            // 
            this.txtbox_DName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_DName.Location = new System.Drawing.Point(91, 63);
            this.txtbox_DName.Name = "txtbox_DName";
            this.txtbox_DName.Size = new System.Drawing.Size(264, 27);
            this.txtbox_DName.TabIndex = 1;
            this.txtbox_DName.TextChanged += new System.EventHandler(this.txtbox_DName_TextChanged);
            // 
            // lbl_Occupation
            // 
            this.lbl_Occupation.AutoSize = true;
            this.lbl_Occupation.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Occupation.Location = new System.Drawing.Point(12, 107);
            this.lbl_Occupation.Name = "lbl_Occupation";
            this.lbl_Occupation.Size = new System.Drawing.Size(129, 25);
            this.lbl_Occupation.TabIndex = 2;
            this.lbl_Occupation.Text = "Occupation:";
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.Location = new System.Drawing.Point(12, 154);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(138, 25);
            this.lbl_DOB.TabIndex = 4;
            this.lbl_DOB.Text = "Date of Birth:";
            // 
            // dtp_DOB
            // 
            this.dtp_DOB.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_DOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_DOB.Location = new System.Drawing.Point(156, 149);
            this.dtp_DOB.Name = "dtp_DOB";
            this.dtp_DOB.Size = new System.Drawing.Size(199, 30);
            this.dtp_DOB.TabIndex = 5;
            this.dtp_DOB.ValueChanged += new System.EventHandler(this.dtp_DOB_ValueChanged);
            // 
            // btn_save
            // 
            this.btn_save.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.Location = new System.Drawing.Point(613, 259);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(119, 42);
            this.btn_save.TabIndex = 6;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // btn_cancel
            // 
            this.btn_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Location = new System.Drawing.Point(738, 259);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(119, 42);
            this.btn_cancel.TabIndex = 7;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // dtp_AddClaim
            // 
            this.dtp_AddClaim.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_AddClaim.Location = new System.Drawing.Point(532, 20);
            this.dtp_AddClaim.Name = "dtp_AddClaim";
            this.dtp_AddClaim.Size = new System.Drawing.Size(200, 22);
            this.dtp_AddClaim.TabIndex = 8;
            // 
            // btn_addclaim
            // 
            this.btn_addclaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addclaim.Location = new System.Drawing.Point(753, 11);
            this.btn_addclaim.Name = "btn_addclaim";
            this.btn_addclaim.Size = new System.Drawing.Size(104, 42);
            this.btn_addclaim.TabIndex = 9;
            this.btn_addclaim.Text = "Add Claim";
            this.btn_addclaim.UseVisualStyleBackColor = true;
            this.btn_addclaim.Click += new System.EventHandler(this.btn_addclaim_Click);
            // 
            // dtg_claims
            // 
            this.dtg_claims.AllowUserToAddRows = false;
            this.dtg_claims.AllowUserToOrderColumns = true;
            this.dtg_claims.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_claims.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.ClaimDate});
            this.dtg_claims.Location = new System.Drawing.Point(532, 59);
            this.dtg_claims.Name = "dtg_claims";
            this.dtg_claims.RowTemplate.Height = 24;
            this.dtg_claims.Size = new System.Drawing.Size(325, 194);
            this.dtg_claims.TabIndex = 10;
            // 
            // Id
            // 
            this.Id.HeaderText = "ID";
            this.Id.Name = "Id";
            // 
            // ClaimDate
            // 
            this.ClaimDate.HeaderText = "Claim Date";
            this.ClaimDate.Name = "ClaimDate";
            // 
            // txtbox_occupation
            // 
            this.txtbox_occupation.Location = new System.Drawing.Point(147, 107);
            this.txtbox_occupation.Name = "txtbox_occupation";
            this.txtbox_occupation.Size = new System.Drawing.Size(208, 22);
            this.txtbox_occupation.TabIndex = 11;
            
            // 
            // frm_addDriver
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 313);
            this.Controls.Add(this.txtbox_occupation);
            this.Controls.Add(this.dtg_claims);
            this.Controls.Add(this.btn_addclaim);
            this.Controls.Add(this.dtp_AddClaim);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.dtp_DOB);
            this.Controls.Add(this.lbl_DOB);
            this.Controls.Add(this.lbl_Occupation);
            this.Controls.Add(this.txtbox_DName);
            this.Controls.Add(this.label1);
            this.Name = "frm_addDriver";
            this.Text = "Add Driver";
            ((System.ComponentModel.ISupportInitialize)(this.dtg_claims)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbox_DName;
        private System.Windows.Forms.Label lbl_Occupation;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.DateTimePicker dtp_DOB;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.DateTimePicker dtp_AddClaim;
        private System.Windows.Forms.Button btn_addclaim;
        private System.Windows.Forms.DataGridView dtg_claims;
        private System.Windows.Forms.TextBox txtbox_occupation;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClaimDate;
    }
}