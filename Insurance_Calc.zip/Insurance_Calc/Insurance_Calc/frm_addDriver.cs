﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Insurance_Calc.Models;
using System.Text.RegularExpressions;

namespace Insurance_Calc
{
    public partial class frm_addDriver : Form
    {
        public Policy policynew; //used to take policy object from previous form
         
        public static Random rnd = new Random();
        public static int id = rnd.Next(1,1000);

        //initialise policy object
        public Driver driver = new Driver()
        {

            DriverId = id,
            Name = "",
            DateOfBirth = DateTime.Now,
            OccupationId = 0,
            Claims = new List<Claim>()

        };

        public frm_addDriver()
        {
            InitializeComponent();
        }

         
        //private void get_filldatatables(object sender, EventArgs e)
        //{
        //    //sets datasource for gridview on load
        //    dtg_claims.DataSource = claims();
        //}

      

        //public DataTable claims()
        //{
        //    DataTable dtclaims = new DataTable();
        //    dtclaims.Columns.Add("id", typeof(System.Int16));
        //    dtclaims.Columns.Add("name", typeof(System.DateTime));

        //    return dtclaims;
        //}

        private void btn_addclaim_Click(object sender, EventArgs e)
        {
            //get last id value and add one to it
            int id = dtg_claims.Rows.Count + 1;
            //get selected date
            DateTime claimDate = dtp_DOB.Value.Date;

            //check that there arent too many claims already
            Rules.Delination.ClaimsRules claimsamount = new Rules.Delination.ClaimsRules();
            string cnt = claimsamount.DriverClaimAmount(driver);

            if (cnt == "pass")
            {
                //add selected claim for driver
                dtg_claims.Rows.Add(id, claimDate);

                

                Claim claim = new Claim();
                claim.ClaimId = get_claimid();
                claim.Date = dtp_AddClaim.Value;
                claim.DriverId = get_driverid(driver);

                //add claim to list in driver object
                driver.Claims.Add(claim);
            }
            else
            {
                MessageBox.Show(cnt);
            }

           
        }

        private int get_claimid()
        {   
            //get last id for claim list and add 1
            int lastid = 0 ;

            DataGridViewRow lastRow = dtg_claims.Rows[dtg_claims.Rows.Count - 1];
            lastid = Convert.ToInt16(lastRow.Cells[0].Value.ToString());
            return lastid + 1;
        }

        private int get_driverid(Driver driver)
        {
            //get current driverid
            int driverid = 0;
            driverid = driver.DriverId;

            return driverid;
        }
      

      
        private void btn_save_Click(object sender, EventArgs e)
        {
            //update id for drivers occupation
            update_occupationid();

            //add driver to list of policy drivers
            //policy object list
            policynew.Drivers.Add(driver); 


            //Complete calculation of declination rules for drivers
            string str_reason = string.Empty;
            //Age Declination rules
            Rules.Delination.DriverAgeRules driveragerules = new Rules.Delination.DriverAgeRules();
           
            if (driveragerules.agerules(policynew, ref str_reason) == true)
            {
                MessageBox.Show(str_reason);
                Application.Exit();
            }

            //Claims Declination rules
            Rules.Delination.ClaimsRules claimsrules = new Rules.Delination.ClaimsRules();
            string strResponse = claimsrules.DriverClaimAmount(driver);

            if (strResponse  == "pass")
            {
                strResponse = claimsrules.DriverClaims(policynew);
                if (strResponse == "pass")
                {
                    strResponse = claimsrules.PolicyClaims(policynew);
                    if (strResponse == "pass")
                    {
                        //Passes all Declination rules
                        //Calculate Premium for claims and occupations calculation rules.
                        Rules.Calculation.DriverClaimsRule claimscalc = new Rules.Calculation.DriverClaimsRule();
                        Rules.Calculation.DriverOccupationRule occupationcalc = new Rules.Calculation.DriverOccupationRule();
                        //update premium on form
                        policynew.Premium = claimscalc.claimsrules(policynew);
                        policynew.Premium = occupationcalc.occupationrules(policynew);


                        //repoen Policy form with updated object
                        frm_addPolicy updatePolicy = new frm_addPolicy();
                        updatePolicy.MdiParent = frm_Main.ActiveForm;
                        
                      


                        //check if user is finished adding drivers, if yes then apply age rules
                        

                        DialogResult drDrivers = MessageBox.Show("Have you finished adding Drivers to the Policy?",
                                                                 "Attention!",
                                                                 MessageBoxButtons.YesNoCancel,
                                                                 MessageBoxIcon.Question,
                                                                 MessageBoxDefaultButton.Button2);

                     

                        if (drDrivers == DialogResult.Yes)
                        {
                            //finish rules calculations 
                            Rules.Calculation.DriverAgeRule agecalc = new Rules.Calculation.DriverAgeRule();
                            policynew.Premium = agecalc.ageRules(policynew);
                            //set add driver buttons to not visible since user if finished adding drivers.
                            updatePolicy.setbtnDriver(false);
                        }

                        updatePolicy.policy = policynew;
                        updatePolicy.Show();

                        //close the form and dispose objects
                        // cbox_Occupation.Dispose();
                        dtg_claims.Dispose();
                        closeForm();

                    }
                    else
                    {
                        MessageBox.Show(strResponse);
                        Application.Exit();
                    }

                }
                else
                {
                    MessageBox.Show(strResponse);
                    Application.Exit();
                }
            }
            else
            {
                MessageBox.Show(strResponse);
                Application.Exit();
            }


         
             

        }

        private void closeForm()
        {
           // cbox_Occupation.Dispose();
            dtg_claims.Dispose();
            dtp_DOB.Dispose();
            dtp_AddClaim.Dispose();
            
            this.Close();
        }

        private void txtbox_DName_TextChanged(object sender, EventArgs e)
        {
            //update onject
            driver.Name = txtbox_DName.Text;
            
        }

     

        private void dtp_DOB_ValueChanged(object sender, EventArgs e)
        {
            //update object
            driver.DateOfBirth = dtp_DOB.Value;
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {

            this.Close();
        }

      

        private void update_occupationid()
        {
            //get typed object and compare to saved list
            string temp = txtbox_occupation.Text.ToUpper();
            Occupation objOccupation = new Occupation();
            List<string> jobs = objOccupation.jobs();

            foreach (string job in jobs)
            {
                string[] split = Regex.Split(job, "_");

                if (temp == split[1].ToString())
                {
                    //update object
                    driver.OccupationId = Convert.ToInt16(split[0].ToString());
                    return;
                }

            }
        }

       
    }
}
