﻿namespace Insurance_Calc
{
    partial class frm_addPolicy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStartDate = new System.Windows.Forms.Label();
            this.dtp_StartDate = new System.Windows.Forms.DateTimePicker();
            this.btn_AddDriver = new System.Windows.Forms.Button();
            this.dgv_Drivers = new System.Windows.Forms.DataGridView();
            this.lbl_premium = new System.Windows.Forms.Label();
            this.lblPremiumValue = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Drivers)).BeginInit();
            this.SuspendLayout();
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartDate.Location = new System.Drawing.Point(215, 22);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(128, 29);
            this.lblStartDate.TabIndex = 0;
            this.lblStartDate.Text = "Start Date";
            // 
            // dtp_StartDate
            // 
            this.dtp_StartDate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_StartDate.Location = new System.Drawing.Point(349, 27);
            this.dtp_StartDate.Name = "dtp_StartDate";
            this.dtp_StartDate.Size = new System.Drawing.Size(174, 22);
            this.dtp_StartDate.TabIndex = 1;
            this.dtp_StartDate.ValueChanged += new System.EventHandler(this.dtp_StartDate_ValueChanged);
            // 
            // btn_AddDriver
            // 
            this.btn_AddDriver.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddDriver.Location = new System.Drawing.Point(12, 65);
            this.btn_AddDriver.Name = "btn_AddDriver";
            this.btn_AddDriver.Size = new System.Drawing.Size(511, 41);
            this.btn_AddDriver.TabIndex = 2;
            this.btn_AddDriver.Text = "Add Driver";
            this.btn_AddDriver.UseVisualStyleBackColor = true;
            this.btn_AddDriver.Click += new System.EventHandler(this.btn_AddDriver_Click);
            // 
            // dgv_Drivers
            // 
            this.dgv_Drivers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Drivers.Location = new System.Drawing.Point(12, 112);
            this.dgv_Drivers.Name = "dgv_Drivers";
            this.dgv_Drivers.RowTemplate.Height = 24;
            this.dgv_Drivers.Size = new System.Drawing.Size(511, 228);
            this.dgv_Drivers.TabIndex = 3;
            // 
            // lbl_premium
            // 
            this.lbl_premium.AutoSize = true;
            this.lbl_premium.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_premium.Location = new System.Drawing.Point(7, 343);
            this.lbl_premium.Name = "lbl_premium";
            this.lbl_premium.Size = new System.Drawing.Size(124, 29);
            this.lbl_premium.TabIndex = 4;
            this.lbl_premium.Text = "Premium:";
            // 
            // lblPremiumValue
            // 
            this.lblPremiumValue.AutoSize = true;
            this.lblPremiumValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPremiumValue.Location = new System.Drawing.Point(137, 343);
            this.lblPremiumValue.Name = "lblPremiumValue";
            this.lblPremiumValue.Size = new System.Drawing.Size(69, 29);
            this.lblPremiumValue.TabIndex = 5;
            this.lblPremiumValue.Text = "£500";
            // 
            // frm_addPolicy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 400);
            this.Controls.Add(this.lblPremiumValue);
            this.Controls.Add(this.lbl_premium);
            this.Controls.Add(this.dgv_Drivers);
            this.Controls.Add(this.btn_AddDriver);
            this.Controls.Add(this.dtp_StartDate);
            this.Controls.Add(this.lblStartDate);
            this.Name = "frm_addPolicy";
            this.Text = "Add Policy";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Drivers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.DateTimePicker dtp_StartDate;
        private System.Windows.Forms.Button btn_AddDriver;
        private System.Windows.Forms.DataGridView dgv_Drivers;
        private System.Windows.Forms.Label lbl_premium;
        private System.Windows.Forms.Label lblPremiumValue;
    }
}