﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Insurance_Calc.Rules;
using Insurance_Calc.Models;

namespace Insurance_Calc 
{
    
    public partial class frm_addPolicy : Form
    {

        //initialise policy object
        public Policy policy;
        //{
            
        //};
     

        public frm_addPolicy()
        {
            InitializeComponent();
            Shown += new EventHandler(Form_Load);
            
           
           
        }

        void Form_Load(object sender, EventArgs e)
        {
            //if policy is null then initialise
            if (policy == null)
            {
                policy = new Policy();
                policy.StartDate = DateTime.Today;
                policy.Drivers = new List<Driver>();
                policy.Premium = Helper.policyStartPrice;

            }

            lblPremiumValue.Text = policy.Premium.ToString();
            dgv_Drivers.DataSource = policy.Drivers;

        }

        frm_addDriver drivernew;
        private void btn_AddDriver_Click(object sender, EventArgs e)
        {
            //check that amount of drivers does no exceed 5
            Rules.Declination.DriverAmountsRules drivercnt = new Rules.Declination.DriverAmountsRules();
            
            string driveramount = drivercnt.AmountRules(policy);
            if (driveramount == "pass")
            {
                 if (drivernew == null)
                {
                    drivernew = new frm_addDriver();
                    drivernew.MdiParent = frm_Main.ActiveForm;
                    drivernew.policynew = policy;
                    drivernew.Show();
                    this.Close();
                }
                else
                {
                    drivernew.Activate();
                }
            }
            else
            {
                MessageBox.Show(driveramount);
            }

           
           
            
        }
        public void setbtnDriver(bool flag)
        {
            //this is used to set the button to add a driver as invisible if the user selected yes at the end messagebox when adding a driver
            this.btn_AddDriver.Visible = flag;
        }
        private void dtp_StartDate_ValueChanged(object sender, EventArgs e)
        {
            //if datetime is previous to today. Deny premium
            policy.StartDate = dtp_StartDate.Value;
            Rules.Delination.PolicyStartDateRules daterules = new Rules.Delination.PolicyStartDateRules();
            string strreason = string.Empty;

            if (daterules.DateRules(policy, ref strreason) == true)
            {
                MessageBox.Show(strreason);
            }
        }
    }
}
